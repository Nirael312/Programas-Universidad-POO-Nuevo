
public class Cosa {
    private int cosa;

    public Cosa(int cosa) {
        this.cosa = cosa;
    }

    public int getCosa() {
        return cosa;
    }
}